const firebaseConfig = {
    apiKey: "AIzaSyDRzCmu54t_Bmu22iv3iIGuDF6y0R2mDpc",
    authDomain: "my-contact--form.firebaseapp.com",
    databaseURL: "https://my-contact--form-default-rtdb.firebaseio.com",
    projectId: "my-contact--form",
    storageBucket: "my-contact--form.appspot.com",
    messagingSenderId: "60933370664",
    appId: "1:60933370664:web:b274a8288c04bf4441961d",
    measurementId: "G-6WEM4EVJFD"
  };

firebase.initializeApp(firebaseConfig);

const contactFormDb = firebase.database().ref('my-contact--form');
document.getElementById('contact-form').addEventListener('submit', submitForm);

const getElementValue = (id) => {
    return document.getElementById(id).value;
}

